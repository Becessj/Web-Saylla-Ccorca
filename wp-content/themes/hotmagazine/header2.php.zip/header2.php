<?php $custom  = hotmagazine_custom(); ?>
		<!-- Header
		    ================================================== -->
		<header class="clearfix  second-style ">
			<!-- Bootstrap navbar -->
			<nav class="navbar navbar-default navbar-static-top" role="navigation">
				<?php if($custom['topline']==true){  ?>
				<!-- Top line -->
				<div class="top-line">
					<div class="container">
						<div class="row">
							<div class="col-md-9">
								<?php $city= $custom['city'];
								$city = $string = str_replace(' ', '', $city);
								$country = $custom['country']; ?>
								<?php if($city!=''){ ?>
									<ul class="top-line-list">
										
										<li><span class="time-now"><?php 
											echo date_i18n( 'l d F Y / '.get_option( 'time_format' ), current_time( 'timestamp', 0 ) );
										?></span></li>
										
									</ul>
									<?php } ?>
									<?php 
							
										$defaults2= array(
											'theme_location'  => 'top',
											'menu'            => '',
											'container'       => '',
											'container_class' => '',
											'container_id'    => '',
											'menu_class'      => 'top-line-list top-menu',
											'menu_id'         => '',
											'echo'            => true,
											 'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
											 
											'before'          => '',
											'after'           => '',
											'link_before'     => '',
											'link_after'      => '',
											'items_wrap'      => '<ul data-breakpoint="800" id="%1$s" class="%2$s">%3$s</ul>',
											'depth'           => 0,
										);
										if ( has_nav_menu( 'top' ) ) {
											wp_nav_menu( $defaults2 );
										}
									
									?>
							</div>	
							<div class="col-md-3">
								<ul class="social-icons">
									<?php if($custom['facebook']!=''){ ?>
									  <li class="facebook"><a  href="<?php echo esc_url($custom['facebook']); ?>"><i class="fa fa-facebook"></i></a></li>
									  <?php } ?>
									  <?php if($custom['twitter']!=''){ ?>
									  <li class="twitter"><a href="<?php echo esc_url($custom['twitter']); ?>"><i class="fa fa-twitter"></i></a></li>
									  <?php } ?>
									 <?php if($custom['istagram']!=''){ ?>
										<li class="instagram"><a href="<?php echo esc_url($custom['istagram']); ?>"><i class="fa fa-instagram"> </i></a></li>
										<?php } ?>
									  <?php if($custom['google']!=''){ ?>
									  <li class="google"><a  href="<?php echo esc_url($custom['google']); ?>"><i class="fa fa-google-plus"></i></a></li>
									  <?php } ?>
									  <?php if($custom['linkedin']!=''){ ?>
									  <li class="linkedin"><a  href="<?php echo esc_url($custom['linkedin']); ?>"><i class="fa fa-linkedin"></i></a></li>
									  <?php } ?>
									  <?php if($custom['pinterest']!=''){ ?>
									  <li class="pinterest" ><a href="<?php echo esc_url($custom['pinterest']); ?>"><i class="fa fa-pinterest"></i></a></li>
									  <?php } ?>
								</ul>
							</div>	
						</div>
					</div>
				</div>
				<!-- End Top line -->
				<?php } ?>
				<!-- Logo & advertisement -->
				<div class="logo-advertisement">
					<div class="container">

						<!-- Brand and toggle get grouped for better mobile display -->
						<div class="navbar-header">
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
							
							<a class="navbar-brand"  href="<?php echo esc_url(home_url('/')); ?>" title="<?php bloginfo('name'); ?>">
							<?php if(is_page(321)){ ?>
								<img src="<?php echo get_template_directory_uri(); ?>/images/logo-black.png" alt="">
							<?php }elseif($custom['logo']['url']!=''){ ?>
								<img src="<?php echo esc_attr($custom['logo']['url']); ?>" alt="<?php bloginfo('name'); ?>">
							  <?php }else{ ?>
								<?php bloginfo('name'); ?>
							  <?php } ?>
						</a>
						</div>
						<?php if(is_page(321)){ ?>
							<div class="advertisement">
							<div class="desktop-advert">Advertisement
							<img src="http://localhost/hotmagazine/wp-content/uploads/2015/11/728x90-white.jpg" alt="adv"></div>
							<div class="tablet-advert">Advertisement
							<img src="http://localhost/hotmagazine/wp-content/uploads/2015/11/468x60-white.jpg" alt="adv"></div>
							</div>
						<?php }else{ ?>
						<?php echo do_shortcode($custom['hadv-editor']); ?>
						<?php } ?>

					</div>
				</div>
				<!-- End Logo & advertisement -->

				<!-- navbar list container -->
				<div class="nav-list-container">
					<div class="container">
						<!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
								<?php 
						
									$defaults1= array(
										'theme_location'  => 'primary',
										'menu'            => '',
										'container'       => '',
										'container_class' => '',
										'container_id'    => '',
										'menu_class'      => 'nav navbar-nav navbar-left',
										'menu_id'         => '',
										'echo'            => true,
										 'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
										 'walker'            => new wp_bootstrap_navwalker(),
										'before'          => '',
										'after'           => '',
										'link_before'     => '',
										'link_after'      => '',
										'items_wrap'      => '<ul data-breakpoint="800" id="%1$s" class="%2$s">%3$s</ul>',
										'depth'           => 0,
									);
									if ( has_nav_menu( 'primary' ) ) {
										wp_nav_menu( $defaults1 );
									}
								
								?>
							
						    <?php if($custom['search']==true){  ?>

							<form method="get" class="navbar-form navbar-right" action="<?php echo esc_url( home_url('/') ); ?>" >
								<input type="text" name="s" placeholder="<?php esc_attr_e( 'Search here', 'hotmagazine' ); ?>" />
								<button type="submit" id="search-submit"><i class="fa fa-search"></i></button>
							</form>

							<?php } ?>
						</div>
						<!-- /.navbar-collapse -->
					</div>
				</div>
				<!-- End navbar list container -->

			</nav>
			<!-- End Bootstrap navbar -->

		</header>
		<!-- End Header -->