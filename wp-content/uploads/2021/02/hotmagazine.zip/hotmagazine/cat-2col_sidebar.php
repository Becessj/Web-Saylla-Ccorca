<?php 
/*
*Category Template: 2 Columns Sidebar 
*/
?>
<?php get_header(); ?>
<?php $custom  = hotmagazine_custom(); ?>

		<?php get_template_part( 'category/2colsidebar'); ?>

<?php get_footer(); ?>