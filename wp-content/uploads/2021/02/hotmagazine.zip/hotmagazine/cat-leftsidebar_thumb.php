<?php 
/*
*Category Template: Left Sidebar Thumbnail
*/
?>
<?php get_header(); ?>
<?php get_template_part( 'category/thumbleft'); ?>
<?php get_footer(); ?>