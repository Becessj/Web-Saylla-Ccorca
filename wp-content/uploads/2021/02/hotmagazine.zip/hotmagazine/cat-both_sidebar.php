<?php 
/*
*Category Template: Both Sidebar 
*/
?>
<?php get_header(); ?>
<?php $custom  = hotmagazine_custom(); ?>

		<?php get_template_part( 'category/bothsidebar'); ?>

<?php get_footer(); ?>