<?php 
/*
*Category Template: Large Image Sidebar 
*/
?>
<?php get_header(); ?>
<?php get_template_part( 'category/larimage'); ?>

<?php get_footer(); ?>