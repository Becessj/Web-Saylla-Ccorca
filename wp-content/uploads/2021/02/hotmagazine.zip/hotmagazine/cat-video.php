<?php 
/*
*Category Template: Video
*/
?>
<?php get_header(); ?>
<?php get_template_part( 'category/video'); ?>

<?php get_footer(); ?>